// getBaseUrl, localDateKey, weekKey, monthKey, dayLabel, weekLabel,
// monthLabel, formatTime, faviconUrl all come from common.js.

const SVG_NS = "http://www.w3.org/2000/svg";

const RANGE_CAPACITY_SECONDS = {
  // Purely a visual reference point for the dial (a generous "awake and online" budget)
  today: 16 * 3600,
  week: 16 * 3600 * 7,
  month: 16 * 3600 * 30,
};

let currentRange = "today";
let currentGranularity = "days"; // 'days' | 'weeks' | 'months' — mirrors storage tiers
let currentTrendDomain = null;
let cache = { days: {}, weeks: {}, months: {} };

async function loadStores() {
  const { days = {}, weeks = {}, months = {} } = await chrome.storage.local.get([
    "days",
    "weeks",
    "months",
  ]);
  cache = { days, weeks, months };
}

function currentBucketFor(range) {
  const now = new Date();
  if (range === "today") return cache.days[localDateKey(now)] || {};
  if (range === "week") return cache.weeks[weekKey(now)] || {};
  return cache.months[monthKey(now)] || {};
}

// ---------- Sliding pill toggle indicator ----------

function positionIndicator(container) {
  const active = container.querySelector("button.active");
  const indicator = container.querySelector(".toggle-indicator");
  if (!active || !indicator) return;
  indicator.style.left = `${active.offsetLeft}px`;
  indicator.style.width = `${active.offsetWidth}px`;
}

// ---------- Overview: dial + headline ----------

function renderDial(totalSeconds) {
  const capacity = RANGE_CAPACITY_SECONDS[currentRange];
  const fraction = Math.min(1, totalSeconds / capacity);
  const radius = 84;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - fraction);

  // Update the existing circle's dashoffset (rather than rebuilding the
  // SVG) so the CSS transition on stroke-dashoffset actually animates.
  document.getElementById("dialFill").style.strokeDashoffset = String(offset);

  document.getElementById("dialTotal").textContent = formatTime(totalSeconds);
  document.getElementById("dialCaption").textContent =
    currentRange === "today" ? "tracked today" : currentRange === "week" ? "tracked this week" : "tracked this month";
}

function renderHeadline(totalSeconds, topDomain) {
  const el = document.getElementById("heroHeadline");
  if (totalSeconds === 0) {
    el.textContent =
      currentRange === "today" ? "Nothing logged yet today." : "No activity logged for this range yet.";
    return;
  }
  const clean = topDomain ? topDomain.replace(/^https?:\/\//, "") : null;
  const period = currentRange === "today" ? "today" : currentRange === "week" ? "this week" : "this month";
  el.textContent = clean
    ? `Mostly ${clean} ${period} — ${formatTime(totalSeconds)} tracked in all.`
    : `${formatTime(totalSeconds)} tracked ${period}.`;
}

// ---------- Ledger: sorted, top 5 pinned & badged ----------

function renderLedger(totals) {
  const ledger = document.getElementById("ledger");
  const emptyState = document.getElementById("emptyState");
  ledger.innerHTML = "";

  const rows = Object.entries(totals).sort((a, b) => b[1] - a[1]);
  emptyState.hidden = rows.length > 0;
  if (rows.length === 0) return;

  const maxSeconds = rows[0][1];

  rows.forEach(([domain, seconds], index) => {
    const rank = index + 1;
    const isTop5 = rank <= 5;
    const row = document.createElement("div");
    row.className = "ledger-row" + (isTop5 ? " top5" : "");
    row.style.animationDelay = `${Math.min(index, 10) * 35}ms`;

    const barPct = Math.max(4, Math.round((seconds / maxSeconds) * 100));
    const badge = isTop5
      ? `<span class="rank-badge rank-${rank}">${rank}</span>`
      : `<span class="rank-spacer"></span>`;

    row.innerHTML = `
      <div class="site-cell">
        ${badge}
        <img src="${faviconUrl(domain, 32)}" alt="" onerror="this.src='icons/icon32.png'" />
        <div class="site-info">
          <div class="site-domain">${domain.replace(/^https?:\/\//, "")}</div>
          <div class="site-bar-track"><div class="site-bar-fill" style="width:${barPct}%"></div></div>
        </div>
      </div>
      <div class="time-cell">${formatTime(seconds)}</div>
    `;
    ledger.appendChild(row);
  });
}

async function refreshOverview() {
  const totals = currentBucketFor(currentRange);
  const totalSeconds = Object.values(totals).reduce((s, v) => s + v, 0);
  const topDomain = Object.entries(totals).sort((a, b) => b[1] - a[1])[0]?.[0];

  renderDial(totalSeconds);
  renderHeadline(totalSeconds, topDomain);
  renderLedger(totals);

  document.getElementById("ledgerRangeLabel").textContent =
    currentRange === "today" ? "today" : currentRange === "week" ? "this week" : "this month";
}

// ---------- Trend: any site, up to a year ----------

/** Rank every domain seen in the last 12 months (the months tier is the longest-coverage source). */
function allDomainsRankedByMonths() {
  const totalsByDomain = {};
  for (const bucket of Object.values(cache.months)) {
    for (const [domain, seconds] of Object.entries(bucket)) {
      totalsByDomain[domain] = (totalsByDomain[domain] || 0) + seconds;
    }
  }
  return Object.entries(totalsByDomain)
    .sort((a, b) => b[1] - a[1])
    .map(([domain]) => domain);
}

function populateDomainSelect() {
  const select = document.getElementById("trendDomain");
  const domains = allDomainsRankedByMonths();
  const previous = currentTrendDomain;

  select.innerHTML = domains
    .map((d) => `<option value="${d}">${d.replace(/^https?:\/\//, "")}</option>`)
    .join("");

  if (domains.length === 0) {
    currentTrendDomain = null;
    return;
  }
  currentTrendDomain = domains.includes(previous) ? previous : domains[0];
  select.value = currentTrendDomain;
}

function buildSeriesFor(domain, granularity) {
  const store = cache[granularity];
  const labelFn = granularity === "days" ? dayLabel : granularity === "weeks" ? weekLabel : monthLabel;
  return Object.keys(store)
    .sort()
    .map((key) => ({ label: labelFn(key), seconds: (store[key] && store[key][domain]) || 0 }));
}

function renderTrendChart(series) {
  const svg = document.getElementById("trendChart");
  const axis = document.getElementById("trendAxis");
  const emptyState = document.getElementById("trendEmpty");

  // Keep the <defs> (gradient), only clear previously-drawn bars.
  svg.querySelectorAll("rect").forEach((r) => r.remove());
  axis.innerHTML = "";

  if (series.length === 0) {
    emptyState.hidden = false;
    return;
  }
  emptyState.hidden = true;

  const W = 680;
  const H = 200;
  const gap = series.length > 40 ? 1 : 4;
  const barW = Math.max(1, (W - gap * (series.length - 1)) / series.length);
  const maxSeconds = Math.max(1, ...series.map((s) => s.seconds));

  const bars = series.map((point, i) => {
    const x = i * (barW + gap);
    const rect = document.createElementNS(SVG_NS, "rect");
    rect.setAttribute("x", x.toFixed(1));
    rect.setAttribute("width", barW.toFixed(1));
    rect.setAttribute("y", String(H));
    rect.setAttribute("height", "0");
    rect.setAttribute("rx", "3");
    rect.setAttribute("class", point.seconds === 0 ? "trend-bar empty" : "trend-bar");
    rect.style.transitionDelay = `${Math.min(i, 60) * 8}ms`;

    const title = document.createElementNS(SVG_NS, "title");
    title.textContent = `${point.label}: ${formatTime(point.seconds)}`;
    rect.appendChild(title);

    svg.appendChild(rect);
    return { rect, point };
  });

  // Grow the bars in on the next frame so the CSS transition actually fires.
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      bars.forEach(({ rect, point }) => {
        const h = point.seconds === 0 ? 2 : Math.max(3, (point.seconds / maxSeconds) * (H - 8));
        rect.setAttribute("height", h.toFixed(1));
        rect.setAttribute("y", (H - h).toFixed(1));
      });
    });
  });

  const labelIdxs =
    series.length <= 6
      ? series.map((_, i) => i)
      : [0, Math.floor((series.length - 1) / 2), series.length - 1];
  axis.innerHTML = labelIdxs.map((i) => `<span>${series[i].label}</span>`).join("");
}

function refreshTrend() {
  populateDomainSelect();
  const select = document.getElementById("trendDomain");
  const totalEl = document.getElementById("trendTotal");
  const captionEl = document.getElementById("trendTotalCaption");

  if (!currentTrendDomain) {
    if (select) select.innerHTML = "";
    totalEl.textContent = "—";
    captionEl.textContent = "no sites tracked yet";
    renderTrendChart([]);
    return;
  }

  select.value = currentTrendDomain;
  const series = buildSeriesFor(currentTrendDomain, currentGranularity);
  const total = series.reduce((sum, p) => sum + p.seconds, 0);

  totalEl.textContent = formatTime(total);
  captionEl.textContent =
    currentGranularity === "days"
      ? "total in the last 30 days"
      : currentGranularity === "weeks"
      ? "total in the last year, by week"
      : "total in the last year, by month";

  renderTrendChart(series);
}

// ---------- Wiring ----------

const rangeToggleEl = document.getElementById("rangeToggle");
const trendRangeToggleEl = document.getElementById("trendRangeToggle");

rangeToggleEl.addEventListener("click", async (e) => {
  const btn = e.target.closest("button[data-range]");
  if (!btn) return;
  currentRange = btn.dataset.range;
  rangeToggleEl.querySelectorAll("button").forEach((b) => b.classList.toggle("active", b === btn));
  positionIndicator(rangeToggleEl);
  await refreshOverview();
});

trendRangeToggleEl.addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-gran]");
  if (!btn) return;
  currentGranularity = btn.dataset.gran;
  trendRangeToggleEl.querySelectorAll("button").forEach((b) => b.classList.toggle("active", b === btn));
  positionIndicator(trendRangeToggleEl);
  refreshTrend();
});

document.getElementById("trendDomain").addEventListener("change", (e) => {
  currentTrendDomain = e.target.value;
  refreshTrend();
});

window.addEventListener("resize", () => {
  positionIndicator(rangeToggleEl);
  positionIndicator(trendRangeToggleEl);
});

async function init() {
  await loadStores();
  positionIndicator(rangeToggleEl);
  positionIndicator(trendRangeToggleEl);
  await refreshOverview();
  refreshTrend();
}

init();
