/**
 * Track Me — background service worker
 *
 * Model: exactly one "active domain" is ever being timed at once — the
 * domain shown in the currently-focused window's active tab. Switching
 * tabs, navigating, losing window focus, or going idle all commit
 * whatever time has accrued so far and either start a new timer or stop
 * entirely.
 *
 * IMPORTANT: Chrome unloads this service worker after ~30s of no
 * activity, wiping any plain JS variables. So the "what am I timing,
 * and since when" state lives in chrome.storage.session instead — that
 * survives the worker being killed and restarted, unlike a normal
 * variable. Every handler reads it fresh rather than trusting memory.
 * The once-a-minute alarm also re-derives the active tab from scratch
 * (not just "commit whatever memory says"), so tracking self-heals even
 * if the worker died and events were missed while it was gone.
 *
 * Storage tiers (chrome.storage.local), each a rolling window:
 *   days:   { "2026-08-20": { "https://example.com": 340 /* seconds *\/ } }  — last 30 days
 *   weeks:  { "2026-08-18" /* Monday *\/ : { domain: seconds } }             — last 52 weeks (~1yr)
 *   months: { "2026-08"                  : { domain: seconds } }             — last 12 months
 * Every commit updates all three at once, then each is pruned back down to
 * its window so storage never grows unbounded.
 */

importScripts("common.js");

const HEARTBEAT_ALARM = "trackme-heartbeat";
const IDLE_THRESHOLD_SECONDS = 60;
const MAX_DAYS = 30;
const MAX_WEEKS = 52;
const MAX_MONTHS = 12;

chrome.alarms.create(HEARTBEAT_ALARM, { periodInMinutes: 1 });
chrome.idle.setDetectionInterval(IDLE_THRESHOLD_SECONDS);

async function getSession() {
  const { session } = await chrome.storage.session.get("session");
  return session || { domain: null, startedAt: null, idle: false };
}

async function setSession(patch) {
  const current = await getSession();
  const next = { ...current, ...patch };
  await chrome.storage.session.set({ session: next });
  return next;
}

/** Save whatever time has accrued for the session's domain, then restart the clock. */
async function commit() {
  const session = await getSession();
  if (!session.domain || !session.startedAt) return;

  const now = Date.now();
  const elapsedSeconds = Math.round((now - session.startedAt) / 1000);
  await setSession({ startedAt: now }); // restart the clock regardless

  if (elapsedSeconds <= 0) return;

  const { days = {}, weeks = {}, months = {} } = await chrome.storage.local.get([
    "days",
    "weeks",
    "months",
  ]);

  const nowDate = new Date();
  addSeconds(days, localDateKey(nowDate), session.domain, elapsedSeconds);
  addSeconds(weeks, weekKey(nowDate), session.domain, elapsedSeconds);
  addSeconds(months, monthKey(nowDate), session.domain, elapsedSeconds);

  pruneToLast(days, MAX_DAYS);
  pruneToLast(weeks, MAX_WEEKS);
  pruneToLast(months, MAX_MONTHS);

  await chrome.storage.local.set({ days, weeks, months });
}

/** Stop timing the current domain (committing first) and start timing a new one, if any. */
async function switchTo(domain) {
  await commit();
  await setSession({ domain, startedAt: domain ? Date.now() : null });
}

/** Re-derive the truth from the browser itself — used on every heartbeat so tracking self-heals. */
async function refreshFromActiveWindow() {
  const session = await getSession();
  if (session.idle) return;

  const focused = await chrome.windows.getLastFocused({});
  if (!focused || !focused.focused) {
    if (session.domain !== null) await switchTo(null);
    return;
  }
  const [tab] = await chrome.tabs.query({ active: true, windowId: focused.id });
  const domain = tab && tab.url ? getBaseUrl(tab.url) : null;
  if (domain !== session.domain) {
    await switchTo(domain);
  }
}

// Tab switched within a window
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  const session = await getSession();
  if (session.idle) return;
  const win = await chrome.windows.get(activeInfo.windowId);
  if (!win.focused) return;
  const tab = await chrome.tabs.get(activeInfo.tabId);
  const domain = tab && tab.url ? getBaseUrl(tab.url) : null;
  await switchTo(domain);
});

// URL changed inside the active tab (SPA navigation, address bar, etc.)
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (!changeInfo.url || !tab.active) return;
  const session = await getSession();
  if (session.idle) return;
  const win = await chrome.windows.get(tab.windowId);
  if (!win.focused) return;
  const domain = getBaseUrl(changeInfo.url);
  await switchTo(domain);
});

// Whole browser window gained/lost focus (includes minimizing)
//
// Quirk to work around: opening the extension's own popup can make Chrome
// briefly report WINDOW_ID_NONE (its "you left the browser" signal) even
// though you're still right there. So a NONE doesn't pause immediately —
// it's debounced for a moment, and cancelled if focus comes right back
// (as it does when you're just clicking the toolbar icon). A genuine
// switch away from the browser holds past the debounce and pauses as
// before.
let pauseTimer = null;

chrome.windows.onFocusChanged.addListener(async (windowId) => {
  const session = await getSession();
  if (session.idle) return;

  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    if (pauseTimer) clearTimeout(pauseTimer);
    pauseTimer = setTimeout(() => {
      pauseTimer = null;
      switchTo(null);
    }, 1200);
    return;
  }

  if (pauseTimer) {
    clearTimeout(pauseTimer);
    pauseTimer = null;
  }
  const [tab] = await chrome.tabs.query({ active: true, windowId });
  const domain = tab && tab.url ? getBaseUrl(tab.url) : null;
  await switchTo(domain);
});

// User went idle/locked (no input for IDLE_THRESHOLD_SECONDS) or came back
chrome.idle.onStateChanged.addListener(async (state) => {
  if (state === "active") {
    await setSession({ idle: false });
    await refreshFromActiveWindow();
  } else {
    // "idle" or "locked" — pause the clock
    await setSession({ idle: true });
    await switchTo(null);
  }
});

// Heartbeat: every minute, re-check reality (self-heals a worker that was
// killed and restarted), then save whatever's accrued.
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== HEARTBEAT_ALARM) return;
  await refreshFromActiveWindow();
  await commit();
});

// Save whatever's in flight if the service worker is about to be torn down
chrome.runtime.onSuspend.addListener(() => {
  commit();
});

// Let the popup ask "what are you timing right now, and for how long?"
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "GET_LIVE_STATE") {
    (async () => {
      const session = await getSession();
      const uncommittedSeconds =
        session.domain && session.startedAt
          ? Math.floor((Date.now() - session.startedAt) / 1000)
          : 0;
      sendResponse({ domain: session.domain, uncommittedSeconds, idle: Boolean(session.idle) });
    })();
    return true; // keep the message channel open for the async response
  }
});

// On install/update/browser start, figure out what's currently active
chrome.runtime.onInstalled.addListener(refreshFromActiveWindow);
chrome.runtime.onStartup.addListener(refreshFromActiveWindow);
