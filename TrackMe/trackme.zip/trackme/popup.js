// getBaseUrl, localDateKey, formatTime, formatClock, faviconUrl all come
// from common.js, loaded before this file.

// --- Live counter state -----------------------------------------------
// baseSeconds: already committed to storage for this domain today.
// liveSeconds: elapsed since the background worker's last commit — this
// is the part we tick locally, one second at a time, for a real-time feel.
let currentDomain = null;
let baseSeconds = 0;
let liveSeconds = 0;
let isTracking = false;

function renderTimer() {
  const timeEl = document.getElementById("timeSpent");
  if (!currentDomain) {
    timeEl.textContent = "—";
    return;
  }
  timeEl.textContent = formatClock(baseSeconds + liveSeconds);
}

function tick() {
  if (isTracking) {
    liveSeconds += 1;
    renderTimer();
  }
}

/** Re-fetch ground truth from storage + the background worker's live state. */
async function resync() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const domain = tab && tab.url ? getBaseUrl(tab.url) : null;
  currentDomain = domain;

  const dot = document.getElementById("liveDot");
  const label = document.getElementById("liveLabel");
  const faviconEl = document.getElementById("favicon");
  const domainEl = document.getElementById("domain");

  const { days = {} } = await chrome.storage.local.get("days");
  const today = days[localDateKey()] || {};

  let live = { domain: null, uncommittedSeconds: 0, idle: false };
  try {
    live = (await chrome.runtime.sendMessage({ type: "GET_LIVE_STATE" })) || live;
  } catch {
    // Background worker not reachable for a moment — fall back to stored totals only.
  }

  isTracking = Boolean(domain) && live.domain === domain && !live.idle;

  dot.classList.toggle("on", isTracking);
  label.textContent = isTracking ? "Tracking this tab — live" : domain ? "Paused" : "Not tracked";

  if (domain) {
    faviconEl.src = faviconUrl(domain, 32);
    faviconEl.style.visibility = "visible";
    domainEl.textContent = domain.replace(/^https?:\/\//, "");
    baseSeconds = today[domain] || 0;
    liveSeconds = isTracking ? live.uncommittedSeconds : 0;
  } else {
    faviconEl.style.visibility = "hidden";
    domainEl.textContent = "Not a trackable page";
    baseSeconds = 0;
    liveSeconds = 0;
  }

  renderTimer();

  // Total today across every site, including the current live session.
  const committedTotal = Object.values(today).reduce((sum, s) => sum + s, 0);
  const liveExtra = isTracking ? live.uncommittedSeconds : 0;
  document.getElementById("todayTotal").textContent = formatTime(committedTotal + liveExtra);
}

document.getElementById("openDashboard").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});

resync();
setInterval(tick, 1000); // ticks the visible counter every second
setInterval(resync, 5000); // corrects drift and catches tab/domain changes
