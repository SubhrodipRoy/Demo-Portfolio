# Track Me — Time & Focus Tracker

A Chrome extension (Manifest V3) that tracks how much time you spend on
each website, pauses automatically when the browser isn't focused or
you've gone idle, and gives you a dashboard with a ranked "most used"
list plus a per-site usage trend you can view for up to a year.

Everything is stored locally on your machine via `chrome.storage.local`
— there's no server, no account, and no data ever leaves your device.

## How it works

- **One timer at a time.** Only the domain in the currently active tab
  of the currently focused window is ever being timed. Switching tabs,
  navigating to a new site, or switching to another app pauses the old
  domain and starts (or stops) the new one.
- **Tracks by origin, not full URL.** `cloud.ai/foo/bar` and
  `cloud.ai/baz` both count as time on `cloud.ai`.
- **Pauses when you're not around.** Minimizing the browser, switching
  to another application, or going idle for 60 seconds all pause the
  clock, and resume automatically when you come back.
- **Survives the browser's background worker being killed.** Chrome
  unloads extension service workers after ~30s of inactivity — the
  running timer's state lives in `chrome.storage.session` (which
  survives that) rather than a plain variable, and a once-a-minute
  heartbeat re-derives the truth from the browser itself so tracking
  self-heals if a worker restart is ever missed.

## Storage: three rolling tiers

Every second of tracked time is written into three tiers at once, each
kept as a rolling window so storage never grows unbounded:

| Tier     | Bucketed by         | Retention   |
| -------- | -------------------- | ----------- |
| `days`   | calendar day          | last 30 days |
| `weeks`  | week (Monday start)   | last 52 weeks (~1 year) |
| `months` | calendar month        | last 12 months |

"Today" / "This week" / "This month" in the dashboard read straight
from the current bucket of the matching tier — no on-the-fly summing
needed. The per-site trend chart reads across all the buckets in a
tier to show up to a year of history (weekly or monthly), or 30 days
of daily detail.

## Files

| File            | Purpose                                                          |
| --------------- | ----------------------------------------------------------------- |
| `manifest.json` | MV3 manifest — permissions, background worker, popup, icons.     |
| `common.js`     | Shared helpers (date/week/month keys, formatting, favicons) used by every other script. |
| `background.js` | The tracking engine (service worker).                            |
| `popup.html/css/js` | Small toolbar popup — current site with a live ticking counter. |
| `dashboard.html/css/js` | Full-page dashboard — overview, ranked ledger, trend chart. |
| `icons/`        | Extension icons (16/32/48/128px).                                |

## Installing it locally

1. Go to `chrome://extensions`.
2. Turn on **Developer mode** (top right).
3. Click **Load unpacked** and select this `trackme` folder.
4. Pin the extension so its icon stays visible in the toolbar.
5. Browse normally — click the icon any time to see the current site's
   live time, or click **Open full dashboard** for the full view.

## The dashboard

- **Today / This week / This month** toggle switches which bucket the
  dial, headline, and ledger below are computed from.
- The **ledger** lists every domain touched in that range, sorted by
  time. The **top 5** get a numbered badge (brass for #1, fading down
  for #2–5) so the most-used sites are always immediately visible at
  the top of the list.
- The **usage trend** section lets you pick any site you've visited
  and see its history as a bar chart:
  - **Daily · 30 days** — day-by-day detail.
  - **Weekly · 1 year** — a full year, bucketed by week.
  - **Monthly · 1 year** — a full year, bucketed by month.
  - Hover a bar for its exact date/time. The total for the selected
    range is shown above the chart.

## Ideas for next steps

- Swap the fixed "16 hours" dial budget for a user-configurable daily
  goal.
- Add a per-site daily time limit with a warning notification.
- Export the `days`/`weeks`/`months` objects as CSV/JSON.
- Let the trend chart compare two sites side by side.
