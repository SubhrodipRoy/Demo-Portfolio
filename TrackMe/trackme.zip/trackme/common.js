/**
 * Track Me — shared helpers.
 * Loaded by background.js via importScripts(), and by popup.html /
 * dashboard.html via a plain <script> tag before their own script.
 * Kept dependency-free so it works in both the service worker and
 * extension-page contexts.
 */

function getBaseUrl(url) {
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return null;
    return parsed.origin;
  } catch {
    return null;
  }
}

function pad2(n) {
  return String(n).padStart(2, "0");
}

function localDateKey(date = new Date()) {
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}

/** Monday of the given date's week, at local midnight. */
function mondayOf(date) {
  const d = new Date(date);
  const day = d.getDay(); // 0=Sun..6=Sat
  const diff = (day === 0 ? -6 : 1) - day;
  d.setDate(d.getDate() + diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

/** Week bucket key — the Monday that starts the given date's week. */
function weekKey(date = new Date()) {
  return localDateKey(mondayOf(date));
}

/** Month bucket key, e.g. "2026-08". */
function monthKey(date = new Date()) {
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}`;
}

/** "Aug 24" */
function dayLabel(dateKeyStr) {
  const [y, m, d] = dateKeyStr.split("-").map(Number);
  return new Date(y, m - 1, d).toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

/** "Aug 24" (the Monday a week bucket starts on) */
function weekLabel(mondayKeyStr) {
  return dayLabel(mondayKeyStr);
}

/** "Aug 2026" */
function monthLabel(monthKeyStr) {
  const [y, m] = monthKeyStr.split("-").map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString(undefined, { month: "short", year: "numeric" });
}

/** Add `seconds` for `domain` inside bucket `key` of `store`, creating either as needed. */
function addSeconds(store, key, domain, seconds) {
  const bucket = store[key] || {};
  bucket[domain] = (bucket[domain] || 0) + seconds;
  store[key] = bucket;
}

/** Keep only the most recent `maxCount` buckets (keys must sort chronologically as strings). */
function pruneToLast(store, maxCount) {
  const keys = Object.keys(store).sort();
  while (keys.length > maxCount) {
    delete store[keys.shift()];
  }
}

function formatTime(totalSeconds) {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  if (h === 0 && m === 0) return "<1m";
  if (h === 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}

/** Ticking H:MM:SS (or M:SS under an hour) — for a live counter. */
function formatClock(totalSeconds) {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  return h > 0 ? `${h}:${pad2(m)}:${pad2(s)}` : `${m}:${pad2(s)}`;
}

/** Pull a favicon straight from Chrome's own cache — no network request, no guessing paths. */
function faviconUrl(pageUrl, size = 32) {
  const url = new URL(chrome.runtime.getURL("/_favicon/"));
  url.searchParams.set("pageUrl", pageUrl);
  url.searchParams.set("size", String(size));
  return url.toString();
}
